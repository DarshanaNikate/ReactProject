

const Contact = () => {
  return (
    <section className="min-h-screen bg-gray-300 flex flex-col justify-center items-center">
      <h1 className="text-4xl font-bold text-blue-600">Contact Us</h1>
      <p className="mt-4 text-lg">
        Get in touch with us through the form below.
      </p>
      <form className="mt-8">
        <input
          type="text"
          placeholder="Your Name"
          className="w-full p-2 mb-4 border border-gray-400 rounded"
        />
        <input
          type="email"
          placeholder="Your Email"
          className="w-full p-2 mb-4 border border-gray-400 rounded"
        />
        <textarea
          placeholder="Your Message"
          className="w-full p-2 mb-4 border border-gray-400 rounded"
        ></textarea>
        <button className="bg-blue-600 text-white px-4 py-2 rounded">
          Send Message
        </button>
      </form>
    </section>
  );
};

export default Contact;
