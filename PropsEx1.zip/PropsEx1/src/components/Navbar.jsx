
import PropTypes from "prop-types"; // Import PropTypes

const Navbar = ({ scrollToSection, homeRef, aboutRef, contactRef }) => {
  return (
    <nav className="bg-blue-600 text-white p-4">
      <div className="container mx-auto flex items-center justify-between">
        <div className="text-2xl font-bold">MyWebsite</div>
        <ul className="flex space-x-8">
          <li>
            <button
              onClick={() => scrollToSection(homeRef)}
              className="hover:text-gray-200"
            >
              Home
            </button>
          </li>
          <li>
            <button
              onClick={() => scrollToSection(aboutRef)}
              className="hover:text-gray-200"
            >
              About Us
            </button>
          </li>
          <li>
            <button
              onClick={() => scrollToSection(contactRef)}
              className="hover:text-gray-200"
            >
              Contact Us
            </button>
          </li>
        </ul>
      </div>
    </nav>
  );
};

// Define PropTypes
Navbar.propTypes = {
  scrollToSection: PropTypes.func.isRequired,
  homeRef: PropTypes.object.isRequired,
  aboutRef: PropTypes.object.isRequired,
  contactRef: PropTypes.object.isRequired,
};

export default Navbar;
