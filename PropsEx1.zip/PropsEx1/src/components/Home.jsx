

const Home = () => {
  return (
    <section className="min-h-screen bg-gray-100 flex flex-col justify-center items-center">
      <h1 className="text-4xl font-bold text-blue-600">Welcome to Home!</h1>
      <p className="mt-4 text-lg">This is the Home section of the page.</p>
    </section>
  );
};

export default Home;
