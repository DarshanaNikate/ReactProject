

const About = () => {
  return (
    <section className="min-h-screen bg-gray-200 flex flex-col justify-center items-center">
      <h1 className="text-4xl font-bold text-blue-600">About Us</h1>
      <p className="mt-4 text-lg">
        Learn more about us in this section of the page.
      </p>
    </section>
  );
};

export default About;
